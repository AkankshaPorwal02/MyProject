package com.virtusa.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.Dao.TravelLineDaoIface;
import com.virtusa.model.Admin;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Passenger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;

/**
 * @author pkrishnakant
 *
 */
@Service
@Transactional
public class TravelLineServiceImpl implements TravelLineServiceIface {
	@Autowired
	TravelLineDaoIface adminDaoIface;

	public int adminLogin(String name, String password) {

		return adminDaoIface.adminLogin(name, password);
	}

	public String addAdmin(Admin ad) {

		return adminDaoIface.addAdmin(ad);
	}

	public int addService(Service1 s) {

		return adminDaoIface.addService(s);
	}

	
	/* (non-Javadoc)
	 * @see com.virtusa.services.TravelLineServiceIface#getAllSeat(java.lang.String)
	 */
	public int[] getAllSeat(String serviceid) {

		return adminDaoIface.getAllSeat(serviceid);
	}

	public int getFare(String servid) {

		return adminDaoIface.getFare(servid);
	}

	public int insertCard(Card c) {

		return adminDaoIface.insertCard(c);
	}

	public String insertPayment(String payid, String bookingid, String creditCardNo, int totalFare) {

		return null;
	}


	public boolean check(Card tl) {

		return false;
	}

	public String paymentIdGenrate() {

		return null;
	}

	public String pnrGenrate() {

		return adminDaoIface.pnrGenrate();
	}

	public String passengerIdGenrate() {

		return adminDaoIface.passengerIdGenrate();
	}

	public String genrateServiceId() {

		return adminDaoIface.genrateServiceId();
	}

	public String genrateBookingId() {

		return adminDaoIface.genrateBookingId();
	}

	public String insertInBookMap(String bookingId, String[] pname, String[] page, String[] seatNo) {

		return null;
	}

	public String insertBooking(Passenger passenger, String pnrno, Date journeyDate, String serviceId,
			String passengerId, int noOfSeats, String bookingid, Card card, int fare, List<BookingMap> bookingMap) {

		return adminDaoIface.insertBooking(passenger, pnrno, journeyDate, serviceId, passengerId, noOfSeats, bookingid,
				card, fare, bookingMap);
	}

	public Passenger ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md,
			String psngId, String proof, String proofid) {
		return adminDaoIface.ticketDetail(pnrNo, pname, page, seatNo, md, psngId, proof, proofid);
	}

	public String cancelTicket(String pnrNo) {

		return adminDaoIface.cancelTicket(pnrNo);
	}


	public RetrievalDao pnrDetails(String pnrNo) {

		return adminDaoIface.pnrDetails(pnrNo);
	}

	public String returnAmount(String pnrNo) {

		return adminDaoIface.returnAmount(pnrNo);
	}

	public boolean checkProof(String idtype) {

		return adminDaoIface.checkProof(idtype);
	}

	public List<Service1> displaySchedules() {

		return adminDaoIface.displaySchedules();
	}

	public List<Service1> modifyService(String serviceid) {

		return adminDaoIface.modifyService(serviceid);
	}

	public boolean checkPNR(String pnrno) {

		return adminDaoIface.checkPNR(pnrno);
	}

	public String sendMessage(ContactUs cus) {

		return adminDaoIface.sendMessage(cus);
	}

	public List<ContactUs> getAllMsg() {

		return adminDaoIface.getAllMsg();
	}


	public int addFeedback(Feedback fb) {

		return adminDaoIface.addFeedback(fb);
	}

	public List<Feedback> displayFeedback() {

		return adminDaoIface.displayFeedback();
	}


	public int updateModifyService(Service1 s) {

		return adminDaoIface.updateModifyService(s);
	}

	public List<Service1> findBuses(String from, String to, String active) {

		return adminDaoIface.findBuses(from, to, active);
	}

}
