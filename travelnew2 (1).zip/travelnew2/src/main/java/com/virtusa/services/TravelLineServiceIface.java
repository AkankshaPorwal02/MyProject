package com.virtusa.services;

import java.util.Date;
import java.util.List;

import com.virtusa.model.Admin;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Passenger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;

public interface TravelLineServiceIface {

	int adminLogin(String name, String password);

	String addAdmin(Admin ad);

	List<Service1> findBuses(String from, String to, String active);

	/**
	 * @param serviceid
	 * @return
	 */
	int[] getAllSeat(String serviceid);

	int getFare(String servid);

	int insertCard(Card c);

	String insertPayment(String payid, String bookingid, String creditCardNo, int totalFare);

	String paymentIdGenrate();

	String pnrGenrate();

	String passengerIdGenrate();

	String genrateServiceId();

	String genrateBookingId();

	String insertInBookMap(String bookingId, String[] pname, String[] page, String[] seatNo);

	String insertBooking(Passenger passenger, String pnrno, Date journeyDate, String serviceId, String passengerId,
			int noOfSeats, String bookingid, Card card, int fare, List<BookingMap> bookingMap);

	Passenger ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md, String psngId,
			String proof, String proofnm);

	String cancelTicket(String pnrNo);

	RetrievalDao pnrDetails(String pnrNo);

	String returnAmount(String pnrNo);

	boolean checkProof(String idtype);

	List<Service1> displaySchedules();

	List<Service1> modifyService(String serviceid);

	boolean checkPNR(String pnrno);

	String sendMessage(ContactUs cus);

	List<ContactUs> getAllMsg();

	int addFeedback(Feedback fb);

	List<Feedback> displayFeedback();

	int addService(Service1 s);

	int updateModifyService(Service1 s);
}