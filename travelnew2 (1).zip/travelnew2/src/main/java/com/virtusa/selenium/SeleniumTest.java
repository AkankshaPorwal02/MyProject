package com.virtusa.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\pkrishnakant\\Desktop\\lib\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:8080/travelnew2/tologin");
		// login
		driver.findElement(By.xpath("//*[@id=\"adminName\"]")).sendKeys("krishnakant");
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("pathak");
		driver.findElement(By.xpath("/html/body/div[2]/form/center/div/table/tbody/tr[4]/td/input[1]")).click();

		// Add Admin

		/*
		 * driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[1]/td/input")).sendKeys(
		 * "rishi"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[2]/td/input")).sendKeys(
		 * "pathak"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[3]/td/input")).sendKeys(
		 * "pathak"); driver.findElement(By.xpath(
		 * "/html/body/div[2]/form/center/div/table/tbody/tr[4]/td/input[1]")).click();
		 */

		// Add Service
		/*
		 * driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[1]/a")).click
		 * (); driver.findElement(By.xpath(
		 * "/html/body/nav/div/div[2]/ul[1]/li[1]/ul/li[1]/a/strong")).click(); new
		 * Select(driver.findElement(By.xpath("//*[@id=\"srFrom\"]"))).selectByIndex(2);
		 * new
		 * Select(driver.findElement(By.xpath("//*[@id=\"srTo\"]"))).selectByIndex(4);
		 * new
		 * Select(driver.findElement(By.xpath("//*[@id=\"typeId\"]"))).selectByIndex(2);
		 * driver.findElement(By.xpath("//*[@id=\"fare\"]")).sendKeys("2563");
		 * driver.findElement(By.xpath("//*[@id=\"disKMS\"]")).sendKeys("3200"); new
		 * Select(driver.findElement(By.xpath("//*[@id=\"capacity\"]"))).selectByIndex(3
		 * ); driver.findElement(By.xpath("//*[@id=\"journeyTime\"]")).sendKeys("21");
		 * driver.findElement(By.xpath("//*[@id=\"departureTime\"]")).sendKeys("02:30AM"
		 * );
		 * driver.findElement(By.xpath("//*[@id=\"serviceNo\"]")).sendKeys("PLMN4066BD")
		 * ; driver.findElement(By.
		 * xpath(" /html/body/center/form/table/tbody/tr[10]/td/center/input[1]")).click
		 * ();
		 */

		// View Schedules
		driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[2]/a/strong")).click();

		// view feedback
		driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[1]/a/strong")).click();

		// view contacts

		driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[1]/li[2]/a")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[2]/ul/li[3]/a/strong")).click();

		// Log Out

		driver.findElement(By.xpath(" /html/body/nav/div/div[2]/ul[2]/li/a")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[2]/li[1]/ul/li/a")).click();

		// Home

		driver.get("http://localhost:8080/travelnew2/tohome");
		driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[1]/input")).sendKeys("hyderabad");
		driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[2]/input")).sendKeys("Delhi");
		driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[3]/input")).sendKeys("1");
		// driver.findElement(By.xpath("//*[@id=\"datepicker\"]")).sendKeys("09/25/2019");
		WebElement calElement = driver.findElement(By.xpath("//*[@id=\"datepicker\"]"));
		calElement.click();
		SelectDayFromMultiDateCalendar("27", driver);

		driver.findElement(By.xpath("/html/body/div[1]/center/div/form/ul/li[5]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"service\"]")).click();
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[3]/td/center/button[1]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/table/tbody/tr/td/section[4]/label")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/table/tbody/tr/td/ol/input[1]")).click();
		driver.findElement(By.xpath("/html/body/center/form/table[2]/tbody/tr[3]/td[1]/input")).sendKeys("mANISH Nagar");
		driver.findElement(By.xpath("/html/body/center/form/table[2]/tbody/tr[3]/td[2]/input")).sendKeys("19");
		driver.findElement(By.xpath("/html/body/center/form/table[3]/tbody/tr[2]/td[2]/input")).sendKeys("MANISH123@gmail.com");
		driver.findElement(By.xpath("/html/body/center/form/table[3]/tbody/tr[3]/td[2]/input")).sendKeys("9458689302");
		driver.findElement(By.xpath("/html/body/center/form/table[3]/tbody/tr[5]/td[2]/input")).sendKeys("MNUGV4066N");
		driver.findElement(By.xpath("/html/body/center/form/input")).click();
		driver.findElement(By.xpath("/html/body/center/form/div/input[1]")).click();

		// payment
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[1]/td/input")).sendKeys("3365908741236958");
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[2]/td/input")).sendKeys("KESHAV");
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[3]/td/input")).sendKeys("926");
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[4]/td/input")).sendKeys("03/2028");
		driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[6]/td/input")).click();

        //close ticket
		driver.findElement(By.xpath("/html/body/center/button[2]")).click();
		
		
       //retrieval ticket
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[3]/a")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul[1]/li[3]/ul/li[2]/a/strong")).click();
		driver.findElement(By.xpath("/html/body/form/center/div/table/tbody/tr[1]/td/input")).sendKeys("PNR001");
		driver.findElement(By.xpath("/html/body/form/center/div/table/tbody/tr[2]/td/input")).sendKeys("ABHI4066KMK");
		driver.findElement(By.xpath("/html/body/form/center/div/table/tbody/tr[3]/td/input[1]")).click();
		


	}

	static public void SelectDayFromMultiDateCalendar(String day, WebDriver driver) throws InterruptedException {

		By calendarXpath = By.xpath("//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='" + day + "']");
		driver.findElement(calendarXpath).click();
	}
}
