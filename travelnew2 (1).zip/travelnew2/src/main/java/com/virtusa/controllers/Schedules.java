package com.virtusa.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.Service1;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class Schedules {
	static Logger logger = Logger.getLogger(Schedules.class);

	@Autowired
	TravelLineServiceIface service;

	@RequestMapping(value = "/viewSchedule", method = RequestMethod.GET)
	public ModelAndView viewSchedules() {
		ModelAndView modelAndView = new ModelAndView();
		List<Service1> schedule = service.displaySchedules();
		if (!schedule.isEmpty()) {
			modelAndView.setViewName("Schedules_Admin");
			modelAndView.addObject("adminsch", schedule);
		}
		else {
			modelAndView.setViewName("Schedules_Admin");
			modelAndView.addObject("msg","!No Services Are Available");
		}
		return modelAndView;
	}

	@RequestMapping(value = "toviewschedules", method = RequestMethod.GET)
	public String view(Model m) {
		return "redirect:/viewSchedule";
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/viewUserSchedule", method = RequestMethod.GET)
	public ModelAndView viewUserSchedules() {
		try {
			ModelAndView modelAndView = new ModelAndView();
			List<Service1> schedule = service.displaySchedules();
			if (!(schedule).isEmpty()) {
				modelAndView.setViewName("Schedules");
				modelAndView.addObject("adminsch", schedule);
			} else {
				modelAndView.addObject("noschedule", "No Schedules Are Available!");
				modelAndView.setViewName("Schedules");
			}
			return modelAndView;
		} catch (Exception e) {
		logger.error(e.getMessage());
		}
		return null;
	}

	@RequestMapping(value = "touserschedules", method = RequestMethod.GET)
	public String viewuserschedules(Model m) {
		return "redirect:/viewUserSchedule";
	}

}
