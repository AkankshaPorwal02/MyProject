package com.virtusa.controllers;

import java.util.Calendar;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.ContactUs;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class Contactus {

	static Logger logger = Logger.getLogger(Contactus.class);

	@Autowired
	TravelLineServiceIface service;

	@RequestMapping(value = "/contactus", method = RequestMethod.GET)
	public ModelAndView adminContact() {
		ModelAndView modelAndView = new ModelAndView();
		List<ContactUs> allmsg = service.getAllMsg();
		int x = allmsg.size();
		String s = null;
		if (!allmsg.isEmpty()) {
			modelAndView.setViewName("AllContactusAdminView");
			modelAndView.addObject("listc", allmsg);
			modelAndView.addObject("length", x);
		} else {
			s = "No Contacts Available";
			modelAndView.addObject("nocontact", s);
			modelAndView.setViewName("AllContactusAdminView");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/tocontact", method = RequestMethod.GET)
	public String tocontact() {
		return "AllContactusAdminView";
	}

	/**
	 * @param name
	 * @param email
	 * @param phone
	 * @param msg
	 * @return
	 */
	@RequestMapping(value = "/userContactUs", method = RequestMethod.POST)
	public ModelAndView userContactUs(@RequestParam("name") String name, @RequestParam("email") String email,
			@RequestParam("phone") String phone, @RequestParam("message") String msg) {

		ModelAndView modelAndView = new ModelAndView();
		String s = null;
		Calendar calendar;
		calendar = Calendar.getInstance();
		if (name != null && email != null && phone != null && msg != null) {
			ContactUs contactUs = new ContactUs();
			contactUs.setUsername(name);
			contactUs.setEmail(email);
			contactUs.setPhone(phone);
			contactUs.setMsg(msg);
			contactUs.setDateConatct(calendar.getTime());
			s = service.sendMessage(contactUs);
			if (s != null) {
				modelAndView.addObject("success", s);
				modelAndView.addObject("name", name);
				modelAndView.addObject("email", email);
				modelAndView.addObject("phone", phone);
				modelAndView.addObject("msg", msg);
				modelAndView.setViewName("ContactUs");
			}

			else {
				modelAndView.setViewName("ContactUs");
			}

		} else {
			modelAndView.setViewName("ContactUs");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/toaddcontact", method = RequestMethod.GET)
	public String toaddcontact() {
		return "ContactUs";
	}
}
