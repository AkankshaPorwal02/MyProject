package com.virtusa.controllers;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.services.TravelLineServiceIface;
import org.apache.log4j.Logger;

@Controller
public class CancelTicket {
	// static Logger logger = Logger.getLogger(CancelTicket.class);

	@Autowired
	TravelLineServiceIface travelservice;

	/**
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/cancelTicket", method = RequestMethod.GET)
	public ModelAndView cancelticket(HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		String s3 = null;
		String s = (String) session.getAttribute("pnrnofordelete");
		String s1 = travelservice.returnAmount(s);
		String s2 = travelservice.cancelTicket(s);
		if ("returened AMount".equals(s1) && "ticket cancelled".equals(s2)) {
			s3 = "Your Ticket Has Been Cancelled Successfully";
			modelAndView.addObject("msg", s3);
			modelAndView.setViewName("PNRcheck");

		} else {
			modelAndView.setViewName("PNRcheck");
		}

		return modelAndView;
	}
}
