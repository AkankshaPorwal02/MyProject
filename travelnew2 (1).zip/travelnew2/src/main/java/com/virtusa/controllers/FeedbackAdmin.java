package com.virtusa.controllers;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.model.Feedback;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class FeedbackAdmin {

	static Logger logger = Logger.getLogger(FeedbackAdmin.class);

	@Autowired
	TravelLineServiceIface service;

	/**
	 * @param feed
	 * @return
	 */
	@RequestMapping(value = "/addFeedback", method = RequestMethod.POST)
	public ModelAndView addFeedback(@ModelAttribute("feedback") Feedback feed) {
		ModelAndView modelAndView = new ModelAndView();
		int list = service.addFeedback(feed);
		if (list > 0) {
			modelAndView.setViewName("AddFeedback");
			modelAndView.addObject("msg", "Thank you for your valuable feedback");
		} else {
			modelAndView.setViewName("AddFeedback");
			modelAndView.addObject("msg", "Feedback Not Added");
		}
		return modelAndView;
	}

	@RequestMapping("/toaddfeedback")
	public String toaddfeedback() {
		return "AddFeedback";

	}

	@RequestMapping(value = "/displayfeedback", method = RequestMethod.GET)
	public ModelAndView displayFeedbackAdmin() {
		try {
			ModelAndView modelAndView = new ModelAndView();
			List<Feedback> list = service.displayFeedback();
			if (!list.isEmpty()) {

				modelAndView.setViewName("ViewFeed");
				modelAndView.addObject("feedlist", list);
			} else {
				modelAndView.addObject("feed", "No Feedbacks are available");
				modelAndView.setViewName("ViewFeed");
			}
			return modelAndView;
		} catch (Exception e) {
			logger.error(e.getMessage());

		}
		return null;

	}

}