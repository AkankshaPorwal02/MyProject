package com.virtusa.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.apache.log4j.Logger;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;
import com.virtusa.services.TravelLineServiceIface;

@Controller
public class RetrieveTicket {

	static Logger logger = Logger.getLogger(RetrieveTicket.class);

	@Autowired
	TravelLineServiceIface travelservice;

	/**
	 * @param pnrno
	 * @param idno
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/retrivalTicket", method = RequestMethod.POST)
	public ModelAndView cancelTicket(@RequestParam("pnrno") String pnrno, @RequestParam("IdNo") String idno,
			HttpSession session) {
		
			String s1 = null;

			ModelAndView modelAndView = new ModelAndView();
			if (pnrno != null && idno != null) {
				if (travelservice.checkPNR(pnrno) && travelservice.checkProof(idno)) {
					RetrievalDao rdao = travelservice.pnrDetails(pnrno);
					session.setAttribute("pnrnofordelete", pnrno);
					String pname=rdao.getMasterName();
					String proofname=rdao.getMasterProofType();
					Service1 sobj = rdao.getSer();
					String servno = sobj.getServiceNo();
					int fare=sobj.getFare();
					String from=sobj.getSrFrom();
					String to=sobj.getSrTo();
					String depttime=sobj.getDepartureTime();
					String jtime=sobj.getJourneyTime();
					List<String> allpassNames = rdao.getPname();
					List<Integer> allpassSeats = rdao.getSeatNo();
					Date date = rdao.getJdate();
					int size=allpassNames.size();
					int totalfare=fare*size;
					modelAndView.addObject("passname", allpassNames);
					modelAndView.addObject("passeats", allpassSeats);
					modelAndView.addObject("date", date);
					modelAndView.addObject("pnrno", pnrno);
					modelAndView.addObject("passseats", allpassSeats);
					modelAndView.addObject("serviceobj", sobj);
					modelAndView.addObject("rdao", rdao);
					modelAndView.addObject("totalfare", totalfare);
					modelAndView.addObject("serviceno", servno);
					modelAndView.addObject("srfrom", from);
					modelAndView.addObject("deptime", depttime);
					modelAndView.addObject("jtime", jtime);
					modelAndView.addObject("to", to);
					modelAndView.addObject("pname", pname);
					modelAndView.addObject("proofname", proofname);
					modelAndView.setViewName("retrivalOpen");

				} else {
					s1 = "Not correct pnr or id proof";
					modelAndView.addObject("msg", s1);
					modelAndView.setViewName("PNRcheck");
				}
			}
			return modelAndView;
		

	}

	@RequestMapping(value = "toPnrCheck", method = RequestMethod.GET)
	public String topnrcheck() {
		return "PNRcheck";
	}
}
