
package com.virtusa.Dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.model.Admin;
import com.virtusa.model.Booking;
import com.virtusa.model.BookingMap;
import com.virtusa.model.Card;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.model.Identity;
import com.virtusa.model.Passenger;
import com.virtusa.model.Payment;
import com.virtusa.model.RetrievalDao;
import com.virtusa.model.Service1;

import org.apache.log4j.Logger;

@Repository
public class TravelLineDaoImpl implements TravelLineDaoIface {
	static Logger logger = Logger.getLogger(TravelLineDaoImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public int adminLogin(String name, String pass) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Admin where adminName=:name AND password=:pass");
			query.setParameter("name", name);
			query.setParameter("pass", pass);
			List<Admin> list = query.list();
			if (list.size() > 0) {
				return 1;
			} else {
				return 0;
			}
		} catch (HibernateException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}

	@Transactional
	public String addAdmin(Admin a) {

		try {
			String s = null;

			Session session = sessionFactory.getCurrentSession();

			int n = (Integer) session.save(a);

			if (n > 0) {
				s = "data inserted successfully";
			}
			return s;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.virtusa.Dao.TravelLineDaoIface#getAllSeat(java.lang.String)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.virtusa.Dao.TravelLineDaoIface#getAllSeat(java.lang.String)
	 */
	@Transactional
	public int[] getAllSeat(String serviceid) {
		Session session = sessionFactory.getCurrentSession();
		Query query1 = session.createQuery("select capacity from Service1 where serviceId=:id");
		query1.setParameter("id", serviceid);
		List<Integer> lst = query1.list();
		int cap = lst.get(0);
		int bsl[] = new int[cap + 1];
		int x = 0;
		SQLQuery query = session.createSQLQuery(
				"select bm.seatNo from booking_table2 b inner join bookmap_table2 bm on bm.bookingId=b.bookingId where b.serviceId=:id");
		query.setParameter("id", serviceid);
		List<Integer> l = query.list();

		for (Integer b : l) {
			bsl[x++] = b.intValue();
		}
		int[] a = new int[bsl.length];

		for (int b : bsl) {

			a[b] = b;

		}

		return a;

	}

	@Transactional
	public int getFare(String servid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query1 = session.createQuery("select fare from Service1 where serviceId=:id");
			query1.setParameter("id", servid);
			List<Integer> list = query1.list();

			return list.get(0);
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	public int insertCard(Card c) {
		try {
			Session session = sessionFactory.getCurrentSession();
			int x = (Integer) session.save(c);
			if (x > 0)
				return x;
			else
				return 0;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	public String paymentIdGenrate() {
		try {
			String cmd = "select Case when max(paymentId)is null THEN 'PAY001'\r\n"
					+ "     when max(paymentId) is not null THEN\r\n"
					+ "     Case WHEN convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1<10 THEN\r\n"
					+ "     concat('PAY00',convert(convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     WHEN convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1>=10 AND convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1<100 THEN\r\n"
					+ "     concat('PAY0',convert(convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     WHEN convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1>100 THEN\r\n"
					+ "     concat('PAY',convert(convert(substr(max(paymentId),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     end end paymentId from payment_table2;";
			Session session = sessionFactory.getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String pnrGenrate() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String cmd = "select Case when max(pnrno) is null THEN 'PNR001'\r\n"
					+ "     when max(pnrno) is not null THEN\r\n"
					+ "     Case WHEN convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1<10 THEN\r\n"
					+ "     concat('PNR00',convert(convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     WHEN convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1>=10 AND convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1<100 THEN\r\n"
					+ "     concat('PNR0',convert(convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     WHEN convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1>100 THEN\r\n"
					+ "     concat('PNR',convert(convert(substr(max(pnrno),4),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "     end end pnrno from booking_table2;";

			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String passengerIdGenrate() {
		try {
			String cmd = "select Case when max(passengerId) is null THEN 'P001'\r\n"
					+ " when max(passengerId) is not null THEN \r\n"
					+ "	Case When convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1<10 THEN\r\n"
					+ "concat('P00',convert(convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "WHEN convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1>=10 AND convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1<100 THEN\r\n"
					+ "concat('P0',convert(convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "WHEN convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1>100 THEN\r\n"
					+ "concat('P',convert(convert(substr(max(passengerId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "end end passengerId from passenger_table2;";
			Session session = sessionFactory.getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String genrateServiceId() {
		try {
			String cmd = "select Case when max(serviceId) is null THEN 'S001'\r\n"
					+ " when max(serviceId) is not null THEN \r\n"
					+ "Case When convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1<10 THEN\r\n"
					+ "concat('S00',convert(convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "WHEN convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1>=10 AND convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1<100 THEN\r\n"
					+ "concat('S0',convert(convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "WHEN convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1>100 THEN\r\n"
					+ "concat('S',convert(convert(substr(max(serviceId),2),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "end end serviceId from service_table2;";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	public String genrateBookingId() {
		try {
			String cmd = "select Case when max(bookingId) is null THEN 'BN01'\r\n"
					+ "	 when max(bookingId) is not null THEN \r\n"
					+ "	 Case When convert(substr(max(bookingId),3),UNSIGNED INTEGER)+1<10 THEN\r\n"
					+ "	 concat('BN0',convert(convert(substr(max(bookingId),3),UNSIGNED INTEGER)+1,CHAR))  ELSE\r\n"
					+ "	   concat('BN',CONVERT(convert(substr(max(bookingId),3),UNSIGNED INTEGER)+1,CHAR))\r\n"
					+ "	end end bookingId from booking_table2;";
			Session session = this.getSessionFactory().getCurrentSession();
			SQLQuery query = session.createSQLQuery(cmd);
			List<String> lst = query.list();
			String s = lst.get(0);
			if (s != null)
				return s;
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;

	}

	@Transactional
	public String insertBooking(Passenger passenger, String pnrno, Date journeyDate, String serviceId,
			String passengerId, int noOfSeats, String bookingid, Card card, int fare, List<BookingMap> bookingMap) {

		Session session = sessionFactory.getCurrentSession();
		// Transaction transaction = session.beginTransaction();
		session.save(card);

		// transaction.begin();
		Booking booking = new Booking();
		Date date = new Date();
		booking.setBookingDate(date);
		booking.setJourneyDate(journeyDate);
		booking.setBookingId(bookingid);
		booking.setPnrNo(pnrno);
		booking.setNoOfSeats(noOfSeats);
		booking.setPassengerId(passengerId);
		booking.setServiceId(serviceId);
		booking.setBookmap(bookingMap);
		session.save(booking);
		// transaction.commit();
		// transaction.begin();
		Payment p = new Payment();
		p.setPaymentId(this.paymentIdGenrate());
		p.setBookingId(bookingid);
		p.setCreditCardNo(card.getCardNo());
		p.setTotalFare(fare);
		p.setBookingId(bookingid);
		session.save(p);

		return "booking inserted";
	}

	@Transactional
	public Passenger ticketDetail(String pnrNo, String[] pname, String[] page, String[] seatNo, Passenger md,
			String psngId, String proof, String proofname) {
		try {
			Session session = sessionFactory.getCurrentSession();
			// Transaction transaction = session.beginTransaction();
			Identity identity = new Identity();
			identity.setProofNo(proof);
			identity.setProofName(proofname);
			session.save(identity);
			// transaction.commit();
			// transaction.begin();
			Passenger stm = new Passenger();
			stm.setEmail(md.getEmail());
			stm.setMobNo(md.getMobNo());
			stm.setProofName(md.getProofName());
			stm.setProofNo(md.getProofNo());
			stm.setName(md.getName());
			stm.setPassengerId(psngId);
			session.save(stm);
			// transaction.commit();
			return stm;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	@Transactional
	public String cancelTicket(String pnrNo) {
		int i = 0, j = 1;
		Session session = sessionFactory.getCurrentSession();
		String cmd = "select bookingid,passengerid from booking_table2 where pnrNo=:pnrnum";
		String findcmd = "select proofNo from passenger_table2 where passengerid=:pnr";
		String dcmd1 = "delete from passenger_table2 where passengerId=:psgid";
		String dcmd2 = "delete from bookmap_table2 where bookingId=:bookid";
		String dcmd3 = "delete from payment_table2 where bookingId=:bookid2";
		String dcmd4 = "delete from booking_table2 where bookingId=:bookid3";
		String dcmd5 = "delete from identity_table2 where proofNo=:proofno";
		String bookingid = null;
		String passengerid = null;
		String idno;
		SQLQuery sqlQuery = session.createSQLQuery(cmd);
		sqlQuery.setParameter("pnrnum", pnrNo);
		List<Object[]> obj = sqlQuery.list();
		for (Object[] objects : obj) {
			bookingid = objects[i].toString();
			passengerid = objects[j].toString();
		}
		SQLQuery sqlQuery2 = session.createSQLQuery(findcmd);
		sqlQuery2.setParameter("pnr", passengerid);
		List<String> list = sqlQuery2.list();
		idno = list.get(0);

		SQLQuery sqlQuery5 = session.createSQLQuery(dcmd3);
		sqlQuery5.setParameter("bookid2", bookingid);
		sqlQuery5.executeUpdate();

		SQLQuery sqlQuery4 = session.createSQLQuery(dcmd2);
		sqlQuery4.setParameter("bookid", bookingid);
		sqlQuery4.executeUpdate();

		SQLQuery sqlQuery6 = session.createSQLQuery(dcmd4);
		sqlQuery6.setParameter("bookid3", bookingid);
		sqlQuery6.executeUpdate();

		SQLQuery sqlQuery3 = session.createSQLQuery(dcmd1);
		sqlQuery3.setParameter("psgid", passengerid);
		sqlQuery3.executeUpdate();

		SQLQuery sqlQuery7 = session.createSQLQuery(dcmd5);
		sqlQuery7.setParameter("proofno", idno);
		sqlQuery7.executeUpdate();

		return "ticket cancelled";
	}

	@Transactional
	public RetrievalDao pnrDetails(String pnrNo) {
		Session session = sessionFactory.getCurrentSession();
		String cmd3 = "from Booking where pnrNo=:pnrno";
		// String cmd4 = "select * from service_table2 where serviceId=:service";
		String cmd5 = "select journeyDate from booking_table2 where serviceId=:id";
		String cmd6 = "select * from bookmap_table2 where bookingId=:bookid";
		String cmd7 = "select * from passenger_table2 where passengerId=:passid";
		RetrievalDao rdao = new RetrievalDao();
		Query query = this.getSessionFactory().getCurrentSession().createQuery(cmd3);
		query.setParameter("pnrno", pnrNo);
		Booking booking = (Booking) query.list().get(0);
		String serviceid = booking.getServiceId();
		String bookid = booking.getBookingId();
		String passengerid = booking.getPassengerId();
		Service1 ser = (Service1) session.get(Service1.class, serviceid);
//		List<Object[]> list1 = query2.list();
//		Iterator it = list1.iterator();
//		while (it.hasNext()) {
//			Service1 service = (Service1) it.next();
//			ser.setSrFrom(service.getSrFrom());
//			ser.setSrTo(service.getSrTo());
//			ser.setDepartureTime(service.getDepartureTime());
//			ser.setServiceNo(service.getServiceNo());
//			ser.setFare(service.getFare());
//			ser.setJourneyTime(service.getJourneyTime());
//		}
		rdao.setSer(ser);
		SQLQuery query3 = session.createSQLQuery(cmd5);
		query3.setParameter("id", serviceid);
		List<Date> list2 = query3.list();
		Date d = list2.get(0);
		rdao.setJdate((java.util.Date) d);
		SQLQuery query4 = session.createSQLQuery(cmd6);
		query4.setParameter("bookid", bookid);
		int i = 3;
		int j = 4;
		int k = 5;
		List<String> pnames = new ArrayList<String>();
		List<Integer> seats = new ArrayList<Integer>();
		/*
		 * List<Object[]> bookingMapObjects = query4.list(); List<BookingMap>
		 * bookingMaps = new ArrayList<BookingMap>();
		 */
		List<Object[]> bookingMapObjects = query4.list();

		for (Object[] bookingMap : bookingMapObjects) {
			pnames.add(bookingMap[i].toString());
			seats.add((Integer) bookingMap[j]);
		}
		rdao.setPname(pnames);
		rdao.setSeatNo(seats);
		SQLQuery query5 = sessionFactory.getCurrentSession().createSQLQuery(cmd7);
		query5.setParameter("passid", passengerid);
		List<Object[]> obj = query5.list();
		for (Object[] object : obj) {
			rdao.setMasterName(object[i].toString());
			rdao.setMasterProofType(object[k].toString());
		}

		return rdao;

	}

	@Transactional
	public String returnAmount(String pnrNo) {
		Session session = sessionFactory.getCurrentSession();
		String bookingid = null;
		String cardno = null;
		int balance = 0;
		String cmd1 = "select bookingId from booking_table2 where pnrNo=:pnr";
		String cmd2 = "select creditCardNo from payment_table2 where bookingId=:bookingid";
		String cmd21 = "select totalFare from payment_table2 where bookingId=:bookingid";
		String cmd3 = "update card_table2 set availablebalance=:balance where cardno=:cardno";
		// String cmd4 = "delete from payment_table2 where bookingId=:bookid";
		SQLQuery sqlQuery1 = session.createSQLQuery(cmd1);
		sqlQuery1.setParameter("pnr", pnrNo);
		List<String> list = sqlQuery1.list();
		bookingid = list.get(0);
		SQLQuery sqlQuery2 = session.createSQLQuery(cmd2);
		sqlQuery2.setParameter("bookingid", bookingid);
		List<String> list2 = sqlQuery2.list();
		cardno = list2.get(0);
		SQLQuery sqlQuery21 = session.createSQLQuery(cmd21);
		sqlQuery21.setParameter("bookingid", bookingid);
		List<Integer> list21 = sqlQuery21.list();
		balance = list21.get(0).intValue();
		SQLQuery sqlQuery3 = session.createSQLQuery(cmd3);
		sqlQuery3.setInteger("balance", balance);
		sqlQuery3.setParameter("cardno", cardno);
		sqlQuery3.executeUpdate();
		/*
		 * SQLQuery sqlQuery4 = session.createSQLQuery(cmd4);
		 * sqlQuery4.setParameter("bookid", bookingid); sqlQuery4.executeUpdate();
		 */
		return "returened AMount";
	}

	@Transactional
	public boolean checkProof(String idtype) {
		boolean flag;
		Session session = sessionFactory.getCurrentSession();
		System.out.println(idtype);
		String cmd = "select proofNo from identity_table2 where proofNo=:prroof";
		SQLQuery sqlQuery = session.createSQLQuery(cmd);
		sqlQuery.setParameter("prroof", idtype);
		List<String> list = sqlQuery.list();
		if (list.size() > 0) {
			flag = true;
		} else {
			flag = false;
		}
		System.out.println("proof chk " + flag);
		return flag;
	}

	@Transactional
	public List<Service1> displaySchedules() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 order by serviceId");

			return query.list();
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public List<Service1> modifyService(String serviceid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 where serviceId=:id");
			query.setString("id", serviceid);
			return query.list();
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public boolean checkPNR(String pnrno) {
		boolean flag;
		String cmd = "select pnrNo from booking_table2 where pnrNo=:pnrnum";
		SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(cmd);
		sqlQuery.setParameter("pnrnum", pnrno);
		List<String> bookings = sqlQuery.list();
		if (bookings.isEmpty())
			flag = false;
		else
			flag = true;

		System.out.println("pnr chk " + flag);
		return flag;
	}

	@Transactional
	public String sendMessage(ContactUs cus) {
		try {
			Session session = sessionFactory.getCurrentSession();
			int x = (Integer) session.save(cus);
			if (x > 0)
				return "Your Message Sent Succesfully!";
			else
				return null;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return null;
	}

	@Transactional
	public List<ContactUs> getAllMsg() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from ContactUs ");

			return query.list();
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public int addFeedback(Feedback fb) {
		try {

			Session s = sessionFactory.getCurrentSession();
			s.save(fb);

			return 1;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

	@Transactional
	public List<Feedback> displayFeedback() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Feedback order by feedbackId");

			return query.list();
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	public int addService(Service1 s) {

		Session session = sessionFactory.getCurrentSession();
		int n = 0;
		s.setServiceId(this.genrateServiceId());
		s.setActive("yes");
		session.save(s);
		n = 1;
		if (n > 0)
			return n;
		else
			return 0;
	}

	@Transactional
	public int updateModifyService(Service1 s) {
		try {

			Session session = sessionFactory.getCurrentSession();
			session.update(s);

			return 1;
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;

	}

	@Transactional
	public List<Service1> findBuses(String from, String to, String active) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Service1 where srFrom=:from1 AND srto=:to AND active=:active");
			query.setParameter("from1", from);
			query.setParameter("to", to);
			query.setParameter("active", active);
			return query.list();
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return Collections.emptyList();
	}

	@Transactional
	public int getSeatCapacity(String serviceid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select capacity from Service1 where serviceId=:id");
			query.setParameter("id", serviceid);
			List<Integer> lst = query.list();
			return lst.get(0);
		} catch (HibernateException e) {

			logger.error(e.getMessage());
		}
		return 0;
	}

}
