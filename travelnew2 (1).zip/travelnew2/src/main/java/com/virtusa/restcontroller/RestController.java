package com.virtusa.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import com.virtusa.model.ContactUs;
import com.virtusa.model.Feedback;
import com.virtusa.services.TravelLineServiceIface;

/**
 * @author pkrishnakant
 *
 */
@org.springframework.web.bind.annotation.RestController
public class RestController {
	@Autowired
	TravelLineServiceIface iface;

	@GetMapping(value = "/getFeedbackXml", produces = { org.springframework.http.MediaType.APPLICATION_XML_VALUE })
	public List<Feedback> getFeedbackXml() {
		return iface.displayFeedback();
	}
	

	@GetMapping(value = "/getFeedbackJson", produces = { org.springframework.http.MediaType.APPLICATION_JSON_VALUE })
	public List<Feedback> getFeedbackJson() {
		return iface.displayFeedback();
	}
	
	@GetMapping(value = "/getContactJson", produces = { org.springframework.http.MediaType.APPLICATION_JSON_VALUE })
	public List<ContactUs> getServiceJson() {
		return iface.getAllMsg();
	}

}
