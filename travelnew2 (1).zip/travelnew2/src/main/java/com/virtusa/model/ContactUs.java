package com.virtusa.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "contact_table2")
public class ContactUs {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int srno;

	@Column
	private String username;

	@Column(name = "mail_id")
	private String email;

	@Column
	private String phone;

	@Column(name = "message")
	private String msg;

	@Column
	@Temporal(TemporalType.DATE)
	private Date dateConatct;

	/**
	 * @return
	 */
	public int getSrno() {
		return srno;
	}

	/**
	 * @param srno
	 */
	public void setSrno(int srno) {
		this.srno = srno;
	}

	

	/**
	 * @return
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return
	 */
	public Date getDateConatct() {
		return new Date(dateConatct.getTime());
	}

	
	/**
	 * @param dateConatct
	 */
	public void setDateConatct(Date dateConatct) {
		this.dateConatct = new Date(dateConatct.getTime());
	}


	/**
	 * @return
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}


}
