package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "card_table2")
public class Card {

	@Id
	@NotNull
	private String cardNo;

	@Column
	@NotNull
	@Pattern(regexp = "^[A-Za-z0-9_]{1,15}$",message = "Enter valid Name")
	private String cardHn;

	@Column
	@NotNull
	@Pattern(regexp = "[0-9]{3}",message = "Enter the 3 digit CVV no")
	private int cvvNo;
	
	@Column
	@NotNull
	@Pattern(regexp = "^((0[1-9])|(1[0-2]))\\/((2009)|(20[2-4][0-9]))$",message = "Enter the valid month")
	private String expDate;
	
	@Column
	
	private int availablebalance;

	/**
	 * @return
	 */
	public int getAvailablebalance() {
		return availablebalance;
	}

	/**
	 * @param availablebalance
	 */
	public void setAvailablebalance(int availablebalance) {
		this.availablebalance = availablebalance;
	}

	/**
	 * @return
	 */
	public String getCardNo() {
		return cardNo;
	}

	/**
	 * @param cardNo
	 */
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	/**
	 * @return
	 */
	public String getCardHn() {
		return cardHn;
	}

	/**
	 * @param cardHn
	 */
	public void setCardHn(String cardHn) {
		this.cardHn = cardHn;
	}

	/**
	 * @return
	 */
	public int getCvvNo() {
		return cvvNo;
	}

	/**
	 * @param cvvNo
	 */
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}

	/**
	 * @return
	 */
	public String getExpDate() {
		return expDate;
	}

	/**
	 * @param expDate
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

}
