package com.virtusa.model;

import java.util.Date;
import java.util.List;

/**
 * @author pkrishnakant
 *
 */
public class RetrievalDao {
	private Service1 ser;
	private Date jdate=null;
	private List<String> pname;
	private List<Integer> seatNo;
	private String masterName;
	private String masterProofType;

	

	public String getMasterName() {

		return masterName;
	}

	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}

	public String getMasterProofType() {
		return masterProofType;
	}

	public void setMasterProofType(String masterProofType) {
		this.masterProofType = masterProofType;
	}

	public List<String> getPname() {
		return pname;
	}

	public void setPname(List<String> pname) {
		this.pname = pname;
	}

	public List<Integer> getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(List<Integer> seatNo) {
		this.seatNo = seatNo;
	}

	public Service1 getSer() {
		return ser;
	}

	public void setSer(Service1 ser) {
		this.ser = ser;
	}

	public Date getJdate() {
		return new Date(jdate.getTime());
	}

	public void setJdate(Date jdate) {
		this.jdate = (Date) jdate.clone();
	}

}
