package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author pkrishnakant
 *
 */

@Entity
@Table(name = "bookmap_table2")
public class BookingMap {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookid;
	
	@Column
	private String bookingId;

	@Column
	private int seatNo;
	@Column
	private String pname;
	@Column
	private int age;

	@ManyToOne
	@JoinColumn(name = "bookingId", referencedColumnName = "bookingId", insertable = false, updatable = false)
	private Booking book;

	/**
	 * @return
	 */
	public Booking getBook() {
		return book;
	}

	/**
	 * @return
	 */
	public int getBookid() {
		return bookid;
	}

	/**
	 * @param bookid
	 */
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	/**
	 * @param book
	 */
	public void setBook(Booking book) {
		this.book = book;
	}

	/**
	 * @return
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * @return
	 */
	public int getSeatNo() {
		return seatNo;
	}

	/**
	 * @param seatNo
	 */
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	/**
	 * @return
	 */
	public String getPname() {
		return pname;
	}

	/**
	 * @param pname
	 */
	public void setPname(String pname) {
		this.pname = pname;
	}

	/**
	 * @return
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age
	 */
	public void setAge(int age) {
		this.age = age;
	}

}
