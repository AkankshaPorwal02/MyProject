
package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Required;


/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "admin_tab2")
public class Admin {

	/**
	 * @author pkrishnakant
	 *
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int adminId;

	
	
	@Column
	@Pattern(regexp = "[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", message = "Numbers not allowed in passenger name")
	private String adminName;

	
	@Column
	@NotNull
	private String password;

	/**
	 * @return
	 */
	public int getAdminId() {
		return adminId;
	}

	/**
	 * @param adminId
	 */
	@Required
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	/**
	 * @return
	 */
	public String getAdminName() {
		return adminName;
	}

	/**
	 * @param adminName
	 */
	@Required
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	/**
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 */
	@Required
	public void setPassword(String password) {
		this.password = password;
	}

}