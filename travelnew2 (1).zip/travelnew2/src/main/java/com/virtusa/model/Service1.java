package com.virtusa.model;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "service_table2")
public class Service1 {

	@Id
	private String serviceId;

	@Column
	@NotNull
	private String typeId;

	@Column
	@NotNull
	@Pattern(regexp = "[A-Za-z\\\\s]{1,}[\\\\.]{0,1}[A-Za-z\\\\s]{0,}$",message = "Numbers not allowed in SRFROM")
	private String srFrom;

	@Column
	@NotNull
	@Pattern(regexp = "[A-Za-z\\\\s]{1,}[\\\\.]{0,1}[A-Za-z\\\\s]{0,}$",message = "Numbers not allowed in SRTO")
	
	private String srTo;

	@Column
	@NotNull
	private String journeyTime;

	
	@Column
	@NotNull
	private String departureTime;

	
	@Column
	@NotNull
	private int fare;
	
	@Column(columnDefinition = "varchar(255) default 'yes'")
	private String active;

	@Column
	@NotNull
	private int capacity;

	@Column
	@NotNull
	private int disKMS;

	@Column
	@NotNull
	
	private String serviceNo;

	@OneToMany
	@JoinColumn(name = "serviceId", referencedColumnName = "serviceId", insertable = false, updatable = false)
	private List<Booking> book;

	/**
	 * @return
	 */
	public List<Booking> getBook() {
		return book;
	}

	/**
	 * @param book
	 */
	public void setBook(List<Booking> book) {
		this.book = book;
	}

	/**
	 * @return
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * @param serviceId
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * @return
	 */
	public String getTypeId() {
		return typeId;
	}

	/**
	 * @param typeId
	 */
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	/**
	 * @return
	 */
	public String getSrFrom() {
		return srFrom;
	}

	/**
	 * @param srFrom
	 */
	public void setSrFrom(String srFrom) {
		this.srFrom = srFrom;
	}

	/**
	 * @return
	 */
	public String getSrTo() {
		return srTo;
	}

	/**
	 * @param srTo
	 */
	public void setSrTo(String srTo) {
		this.srTo = srTo;
	}

	/**
	 * @return
	 */
	public String getJourneyTime() {
		return journeyTime;
	}

	/**
	 * @param journeyTime
	 */
	public void setJourneyTime(String journeyTime) {
		this.journeyTime = journeyTime;
	}

	/**
	 * @return
	 */
	public String getDepartureTime() {
		return departureTime;
	}

	/**
	 * @param departureTime
	 */
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	/**
	 * @return
	 */
	public int getFare() {
		return fare;
	}

	/**
	 * @param fare
	 */
	public void setFare(int fare) {
		this.fare = fare;
	}

	/**
	 * @return
	 */
	public String getActive() {
		return active;
	}

	/**
	 * @param active
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * @return
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return
	 */
	public int getDisKMS() {
		return disKMS;
	}

	/**
	 * @param disKMS
	 */
	public void setDisKMS(int disKMS) {
		this.disKMS = disKMS;
	}

	/**
	 * @return
	 */
	public String getServiceNo() {
		return serviceNo;
	}

	/**
	 * @param serviceNo
	 */
	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Service1 [serviceId=" + serviceId + ", typeId=" + typeId + ", srFrom=" + srFrom + ", srTo=" + srTo
				+ ", journeyTime=" + journeyTime + ", departureTime=" + departureTime + ", fare=" + fare + ", active="
				+ active + ", capacity=" + capacity + ", disKMS=" + disKMS + ", serviceNo=" + serviceNo + "]";
	}

}
