package com.virtusa.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "booking_table2")
public class Booking {
	@Id
	private String bookingId;

	@Column
	private String pnrNo;

	@Column
	@Temporal(TemporalType.DATE)
	private Date journeyDate=null;

	@Column
	@Temporal(TemporalType.DATE)
	private Date bookingDate=null;

	@Column
	private String serviceId;

	@Column
	
	private String passengerId;

	@Column
	private int noOfSeats;
	
	@OneToOne
	@JoinColumn(name = "passengerId", referencedColumnName = "passengerId", insertable = false, updatable = false)
	private Passenger passenger;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "bookingId", referencedColumnName = "bookingId", insertable = false, updatable = false)
	private List<BookingMap> bookmap;


	public List<BookingMap> getBookmap() {
		return bookmap;
	}

	public void setBookmap(List<BookingMap> bookmap) {
		this.bookmap = bookmap;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}

	public Date getJourneyDate() {
		return (Date)journeyDate.clone();
	}

	
	/**
	 * @param journeyDate
	 */
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = (Date)journeyDate.clone();
	}

	public Date getBookingDate() {
		return new Date(bookingDate.getTime());
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate =new Date(bookingDate.getTime());
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

}
