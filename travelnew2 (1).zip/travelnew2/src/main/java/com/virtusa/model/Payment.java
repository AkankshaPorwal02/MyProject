package com.virtusa.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author pkrishnakant
 *
 */
@Entity
@Table(name = "payment_table2")
public class Payment {

	@Id
	private String paymentId;

	@Column
	private String bookingId;
	@Column
	private String creditCardNo;

	@Column
	private int totalFare;
	
	@OneToOne
	@JoinColumn(name = "bookingId", referencedColumnName = "bookingId", insertable = false, updatable = false)
	private Booking booking;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "cardNo", referencedColumnName = "creditCardNo", insertable = false, updatable = false)
	private List<Card> cards;
	
	public List<Card> getCards() {
		return cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}
	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public int getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}

}
